# Scrapyd Docker

Docker for Scrapyd

## Usage

```
docker run -d -p 6800:6800 germey/scrapyd
```

## Python Libs

```
requests, selenium, aiohttp, beautifulsoup4, pyquery, pymysql, redis, pymongo, flask, django, scrapy, scrapyd, scrapyd-client, scrapy-redis, scrapy-splash
```