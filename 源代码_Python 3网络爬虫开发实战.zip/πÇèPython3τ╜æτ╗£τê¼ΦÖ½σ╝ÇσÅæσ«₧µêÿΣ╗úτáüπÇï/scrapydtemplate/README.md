# ScrapydDeploy

Scrapyd Deploy Template for Azure
