from weixin.spider import Spider

if __name__ == '__main__':
    spider = Spider()
    spider.run()
