# ScrapyDocker

Docker for Scrapy

## Build

```
docker build -t quotes:latest .
```

## Run

```
docker run quotes
```

## Remote Image

```
docker run -it germey/quotes
```

