Github Login

Login Github with Requests