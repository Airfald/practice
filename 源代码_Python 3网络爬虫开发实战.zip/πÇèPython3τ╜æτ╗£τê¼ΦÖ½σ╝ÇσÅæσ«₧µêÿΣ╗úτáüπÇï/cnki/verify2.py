import tesserocr

print(tesserocr.file_to_text('code.jpg'))